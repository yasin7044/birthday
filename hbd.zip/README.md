# Happy Birthday

## A Happy Birthday animation design in CSS3, HTML5.
## 一个生日祝福网页，基于CSS3 H5 js 

### 说明：
 - 兼容移动端。
 - demo http://love.4d4k.com/birthday/she
 
### 基于https://github.com/ayusharma/birthday进行修改，修改内容：
 - 国内无法访问的一些cdn库
 - 修改样式和js,使其兼容移动手机端（毕竟现在没有几个专门用电脑打开的网页的）
 - 其他一些东西
